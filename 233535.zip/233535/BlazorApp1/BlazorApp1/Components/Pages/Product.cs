﻿namespace BlazorApp1.Components.Pages
{
    public class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Category { get; set; }
    }

}
