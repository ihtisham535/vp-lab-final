﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentProgressTracker
{
    public class Student
    {
        public int StudentID { get; set; }
        public string Name { get; set; }
        public string Grade { get; set; }
        public string Subject { get; set; }
        public int Marks { get; set; }
        public decimal AttendancePercentage { get; set; }
    }
}
