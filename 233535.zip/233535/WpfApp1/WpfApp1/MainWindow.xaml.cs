﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace StudentProgressTracker
{
    public partial class MainWindow : Window
    {
        private StudentContext _context; // Database context
        private List<string> GradeOptions { get; set; }
        private List<string> SubjectOptions { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            _context = new StudentContext(); // Initialize the database context
            InitializeOptions(); // Initialize grade and subject options
            LoadData(); // Load data from the database into the DataGrid
        }

        private void InitializeOptions()
        {
            // Initialize grade options
            GradeOptions = new List<string> { "All" }
                .Concat(_context.Students.Select(s => s.Grade).Distinct().OrderBy(g => g)).ToList();
            GradeComboBox.ItemsSource = GradeOptions;
            GradeComboBox.SelectedIndex = 0; // Default to "All"

            // Initialize subject options
            SubjectOptions = new List<string> { "All" }
                .Concat(_context.Students.Select(s => s.Subject).Distinct().OrderBy(s => s)).ToList();
            SubjectComboBox.ItemsSource = SubjectOptions;
            SubjectComboBox.SelectedIndex = 0; // Default to "All"
        }

        private void LoadData()
        {
            var students = _context.Students.ToList(); // Retrieve all students from the database
            StudentDataGrid.ItemsSource = students;   // Bind the data to the DataGrid
        }

        private void FilterStudents()
        {
            var selectedGrade = GradeComboBox.SelectedItem?.ToString();
            var selectedSubject = SubjectComboBox.SelectedItem?.ToString();

            // Start with all students
            var filteredData = _context.Students.AsQueryable();

            // Apply grade filter if a specific grade is selected and not "All"
            if (!string.IsNullOrEmpty(selectedGrade) && selectedGrade != "All")
            {
                filteredData = filteredData.Where(s => s.Grade.Equals(selectedGrade, StringComparison.OrdinalIgnoreCase));
            }

            // Apply subject filter if a specific subject is selected and not "All"
            if (!string.IsNullOrEmpty(selectedSubject) && selectedSubject != "All")
            {
                filteredData = filteredData.Where(s => s.Subject.Equals(selectedSubject, StringComparison.OrdinalIgnoreCase));
            }

            // Bind the filtered data to the DataGrid
            StudentDataGrid.ItemsSource = filteredData.ToList();
        }

        private void GradeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterStudents();
        }

        private void SubjectComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterStudents();
        }

        private void ShowLoadingIndicator(bool isVisible, string message = "Processing...", Brush backgroundColor = null)
        {
            LoadingProgressBar.Visibility = isVisible ? Visibility.Visible : Visibility.Collapsed;
            LoadingTextBlock.Visibility = isVisible ? Visibility.Visible : Visibility.Collapsed;

            if (isVisible)
            {
                LoadingTextBlock.Text = message;
                LoadingTextBlock.Background = backgroundColor ?? Brushes.LightBlue; // Default background color
            }
        }

        private async void AddButton_Click(object sender, RoutedEventArgs e)
        {
            ShowLoadingIndicator(true, "Adding Student...", Brushes.LightGreen);

            var addStudentWindow = new AddStudentDialog();
            var result = addStudentWindow.ShowDialog();

            if (result == true)
            {
                var newStudent = addStudentWindow.NewStudent;
                _context.Students.Add(newStudent);

                // Save changes asynchronously
                await Task.Run(() =>
                {
                    _context.SaveChanges();
                });

                LoadData(); // Refresh the DataGrid
                MessageBox.Show("Student added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            ShowLoadingIndicator(false);
        }

        private async void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedStudent = StudentDataGrid.SelectedItem as Student;
            if (selectedStudent == null)
            {
                MessageBox.Show("Please select a student to edit.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ShowLoadingIndicator(true, "Editing Student...", Brushes.LightYellow);

            var editDialog = new AddStudentDialog(selectedStudent) { Title = "Edit Student" };

            if (editDialog.ShowDialog() == true)
            {
                selectedStudent.Name = editDialog.StudentName;
                selectedStudent.Grade = editDialog.StudentGrade;
                selectedStudent.Subject = editDialog.StudentSubject;
                selectedStudent.Marks = editDialog.StudentMarks;
                selectedStudent.AttendancePercentage = editDialog.StudentAttendance;

                // Save changes asynchronously
                await Task.Run(() =>
                {
                    _context.SaveChanges();
                });

                LoadData();
                MessageBox.Show("Student edited successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            ShowLoadingIndicator(false);
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (StudentDataGrid.SelectedItem is Student selectedStudent)
            {
                var result = MessageBox.Show("Are you sure you want to delete this student?", "Delete Student", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    ShowLoadingIndicator(true, "Deleting Student...", Brushes.LightCoral);

                    _context.Students.Remove(selectedStudent);

                    // Save changes asynchronously
                    await Task.Run(() =>
                    {
                        _context.SaveChanges();
                    });

                    LoadData();
                    MessageBox.Show("Student deleted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Please select a student to delete.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            ShowLoadingIndicator(false);
        }
    }
}
