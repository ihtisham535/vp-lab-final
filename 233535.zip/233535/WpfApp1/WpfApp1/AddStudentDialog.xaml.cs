﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;

namespace StudentProgressTracker
{
    public partial class AddStudentDialog : Window
    {
        // Properties for input data
        public string StudentName { get; set; }
        public string StudentGrade { get; set; }
        public string StudentSubject { get; set; }
        public int StudentMarks { get; set; }
        public decimal StudentAttendance { get; set; }

        // Properties for grade and subject options
        public List<string> GradeOptions { get; set; }
        public List<string> SubjectOptions { get; set; }

        // NewStudent property for integration with the main window
        public Student NewStudent { get; private set; }

        // Flag to indicate if editing
        private bool _isEditing;
        private Student _studentToEdit;

        public AddStudentDialog()
        {
            InitializeComponent();
            InitializeOptions();
            _isEditing = false;
        }

        public AddStudentDialog(Student student) : this()
        {
            _isEditing = true;
            _studentToEdit = student;

            // Prefill data if editing
            NameTextBox.Text = student.Name;
            GradeComboBox.SelectedItem = student.Grade;
            SubjectComboBox.SelectedItem = student.Subject;
            MarksTextBox.Text = student.Marks.ToString();
            AttendanceTextBox.Text = student.AttendancePercentage.ToString();
        }

        private void InitializeOptions()
        {
            GradeOptions = new List<string> { "A", "B", "C", "D", "F" };
            SubjectOptions = new List<string> { "Math", "Science", "English", "History" };
            GradeComboBox.ItemsSource = GradeOptions;
            SubjectComboBox.ItemsSource = SubjectOptions;
        }

        private async void OKButton_Click(object sender, RoutedEventArgs e)
        {
            // Show loading state
            LoadingProgressBar.Visibility = Visibility.Visible;
            LoadingTextBlock.Visibility = Visibility.Visible;

            // Simulate a delay to show the loading indicator
            await Task.Delay(2000); // Simulate a 2-second delay

            // Validate input fields
            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                ValidationTextBlock.Text = "Please enter a valid name.";
                ValidationTextBlock.Visibility = Visibility.Visible;
                LoadingProgressBar.Visibility = Visibility.Collapsed;
                LoadingTextBlock.Visibility = Visibility.Collapsed;
                return;
            }

            if (GradeComboBox.SelectedItem == null)
            {
                ValidationTextBlock.Text = "Please select a grade.";
                ValidationTextBlock.Visibility = Visibility.Visible;
                LoadingProgressBar.Visibility = Visibility.Collapsed;
                LoadingTextBlock.Visibility = Visibility.Collapsed;
                return;
            }

            if (SubjectComboBox.SelectedItem == null)
            {
                ValidationTextBlock.Text = "Please select a subject.";
                ValidationTextBlock.Visibility = Visibility.Visible;
                LoadingProgressBar.Visibility = Visibility.Collapsed;
                LoadingTextBlock.Visibility = Visibility.Collapsed;
                return;
            }

            if (!int.TryParse(MarksTextBox.Text, out var marks) || marks < 0 || marks > 100)
            {
                ValidationTextBlock.Text = "Please enter valid marks (0-100).";
                ValidationTextBlock.Visibility = Visibility.Visible;
                LoadingProgressBar.Visibility = Visibility.Collapsed;
                LoadingTextBlock.Visibility = Visibility.Collapsed;
                return;
            }

            if (!decimal.TryParse(AttendanceTextBox.Text, out var attendance) || attendance < 0 || attendance > 100)
            {
                ValidationTextBlock.Text = "Please enter a valid attendance percentage (0-100).";
                ValidationTextBlock.Visibility = Visibility.Visible;
                LoadingProgressBar.Visibility = Visibility.Collapsed;
                LoadingTextBlock.Visibility = Visibility.Collapsed;
                return;
            }

            // If validation passes, assign values
            StudentName = NameTextBox.Text;
            StudentGrade = GradeComboBox.SelectedItem.ToString();
            StudentSubject = SubjectComboBox.SelectedItem.ToString();
            StudentMarks = marks;
            StudentAttendance = attendance;

            if (_isEditing)
            {
                // Update existing student if editing
                _studentToEdit.Name = StudentName;
                _studentToEdit.Grade = StudentGrade;
                _studentToEdit.Subject = StudentSubject;
                _studentToEdit.Marks = StudentMarks;
                _studentToEdit.AttendancePercentage = StudentAttendance;
            }
            else
            {
                // Create new student if adding
                NewStudent = new Student
                {
                    Name = StudentName,
                    Grade = StudentGrade,
                    Subject = StudentSubject,
                    Marks = StudentMarks,
                    AttendancePercentage = StudentAttendance
                };
            }

            // Hide loading state
            LoadingProgressBar.Visibility = Visibility.Collapsed;
            LoadingTextBlock.Visibility = Visibility.Collapsed;

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Show loading state
            LoadingProgressBar.Visibility = Visibility.Visible;
            LoadingTextBlock.Visibility = Visibility.Visible;

            // Simulate a delay to show the loading indicator
            Task.Delay(1000).ContinueWith(_ =>
            {
                // Close the dialog
                Dispatcher.Invoke(() =>
                {
                    DialogResult = false;
                    Close();
                });
            });
        }
    }
}
