﻿using System.Collections.Generic;
using System.Data.Entity;

namespace StudentProgressTracker
{
    public class StudentContext : DbContext
    {
        public StudentContext() : base("name=StudentProgressTrackerDB")
        {
        }

        public DbSet<Student> Students { get; set; }
    }
}
